package com.example.challichalli;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Order extends AppCompatActivity {

    TextView t1, t2, t3, t4, itemTextView;

    String name, email, region, postal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_order);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        ImageView img1 = findViewById(R.id.button1);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs1 = new Intent(Order.this, Options.class);
                startActivity(hatdogs1);
            }
        });

        ImageView img2 = findViewById(R.id.button2);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs2 = new Intent(Order.this, MainActivity.class);
                startActivity(hatdogs2);
            }
        });

        ImageView img0 = findViewById(R.id.button3);
        img0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs0 = new Intent(Order.this, Transaction.class);
                startActivity(hatdogs0);
            }
        });

        t1 = findViewById(R.id.Names0);
        t2 = findViewById(R.id.Emails0);
        t3 = findViewById(R.id.Regions0);
        t4 = findViewById(R.id.Postals0);
        itemTextView = findViewById(R.id.Items0);

        SharedPreferences sp = getApplicationContext().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        String name = sp.getString("name", "");
        String email = sp.getString("email", "");
        String region = sp.getString("region", "");
        String postal = sp.getString("postal", "");
        String item = sp.getString("item", "");

        t1.setText(name);
        t2.setText(email);
        t3.setText(region);
        t4.setText(postal);
        itemTextView.setText(item);

    }
}