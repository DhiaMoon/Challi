package com.example.challichalli;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Cakes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cakes);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView img1 = findViewById(R.id.button1);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs1 = new Intent(Cakes.this, Options.class);
                startActivity(hatdogs1);
            }
        });

        ImageView img2 = findViewById(R.id.button2);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs2 = new Intent(Cakes.this, MainActivity.class);
                startActivity(hatdogs2);
            }
        });

        Button btn3 = findViewById(R.id.btn_activity);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog3 = new Intent(Cakes.this, ChocolatecCake.class);
                startActivity(hatdog3);
            }
        });

        ImageView img3 = findViewById(R.id.imageView3s);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs3 = new Intent(Cakes.this, ChocolatecCake.class);
                startActivity(hatdogs3);
            }
        });

        TextView txt = findViewById(R.id.textView);
        txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss = new Intent(Cakes.this, ChocolatecCake.class);
                startActivity(hatdogss);
            }
        });

        Button btn4 = findViewById(R.id.btn2_activity);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog4 = new Intent(Cakes.this, RedVelvetCake.class);
                startActivity(hatdog4);
            }
        });

        ImageView img4 = findViewById(R.id.imageView4);
        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs4 = new Intent(Cakes.this, RedVelvetCake.class);
                startActivity(hatdogs4);
            }
        });

        TextView txt1 = findViewById(R.id.textView2);
        txt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss1 = new Intent(Cakes.this, RedVelvetCake.class);
                startActivity(hatdogss1);
            }
        });

        Button btn5 = findViewById(R.id.btn3_activity);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog5 = new Intent(Cakes.this, Cheesecake.class);
                startActivity(hatdog5);
            }
        });

        ImageView img5 = findViewById(R.id.imageView5);
        img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs5 = new Intent(Cakes.this, Cheesecake.class);
                startActivity(hatdogs5);
            }
        });

        TextView txt2 = findViewById(R.id.textView3);
        txt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss2 = new Intent(Cakes.this, Cheesecake.class);
                startActivity(hatdogss2);
            }
        });

        Button btn6 = findViewById(R.id.btn4_activity);
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog6 = new Intent(Cakes.this, CarrotCake.class);
                startActivity(hatdog6);
            }
        });

        ImageView img6 = findViewById(R.id.imageView6);
        img6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs6 = new Intent(Cakes.this, CarrotCake.class);
                startActivity(hatdogs6);
            }
        });

        TextView txt3 = findViewById(R.id.textView4);
        txt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss3 = new Intent(Cakes.this, CarrotCake.class);
                startActivity(hatdogss3);
            }
        });

        Button btn7 = findViewById(R.id.btn5_activity);
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog7 = new Intent(Cakes.this, SpongeCake.class);
                startActivity(hatdog7);
            }
        });

        ImageView img7 = findViewById(R.id.imageView7);
        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs7 = new Intent(Cakes.this, SpongeCake.class);
                startActivity(hatdogs7);
            }
        });

        TextView txt4 = findViewById(R.id.textView5);
        txt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss4 = new Intent(Cakes.this, SpongeCake.class);
                startActivity(hatdogss4);
            }
        });

    }
}