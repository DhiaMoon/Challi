package com.example.challichalli;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Transaction extends AppCompatActivity {

    EditText name, email, region, postal;
    Button button, button2s;
    SharedPreferences sp;
    String nameStr, emailStr, regionStr, postalStr, itemStr;

    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_transaction);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView img1 = findViewById(R.id.button1);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs1 = new Intent(Transaction.this, Options.class);
                startActivity(hatdogs1);
            }
        });

        ImageView img2 = findViewById(R.id.button2);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs2 = new Intent(Transaction.this, MainActivity.class);
                startActivity(hatdogs2);
            }
        });

        ImageView img0 = findViewById(R.id.button3);
        img0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs0 = new Intent(Transaction.this, Transaction.class);
                startActivity(hatdogs0);
            }
        });

        spinner = findViewById(R.id.my_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner_items, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        name = findViewById(R.id.Names);
        email = findViewById(R.id.Emails);
        region = findViewById(R.id.Regions);
        postal = findViewById(R.id.Postals);
        button = findViewById(R.id.button);
        button2s = findViewById(R.id.button2s);

        sp = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameStr = name.getText().toString();
                String emailStr = email.getText().toString();
                String regionStr = region.getText().toString();
                String postalStr = postal.getText().toString();
                String selectedItem = spinner.getSelectedItem().toString();

                SharedPreferences.Editor editor = sp.edit();
                editor.putString("name", nameStr);
                editor.putString("email", emailStr);
                editor.putString("region", regionStr);
                editor.putString("postal", postalStr);
                editor.putString("item", selectedItem); // Save selected item
                editor.apply();

                Toast.makeText(Transaction.this, "Order Saved", Toast.LENGTH_LONG).show();
            }
        });

        button2s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Transaction.this, Order.class);
                startActivity(intent);
            }
        });

    }
}