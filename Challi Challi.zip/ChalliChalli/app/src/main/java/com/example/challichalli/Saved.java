package com.example.challichalli;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Saved extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_saved);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText searchView = findViewById(R.id.searchView);

        ImageView validateButton = findViewById(R.id.btn14_activity);
        validateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredPassword = searchView.getText().toString();
                if (enteredPassword.equals("Sourdough")) {
                    Intent intent = new Intent(Saved.this, Sourdough.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Baguette")) {
                    Intent intent = new Intent(Saved.this, Baguette.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Rye Bread")) {
                    Intent intent = new Intent(Saved.this, RyeBread.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Whole Wheat Bread")) {
                    Intent intent = new Intent(Saved.this, WholeWheatBread.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Ciabatta")) {
                    Intent intent = new Intent(Saved.this, Ciabatta.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Chocolate Cake")) {
                    Intent intent = new Intent(Saved.this, ChocolatecCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Red Velvet Cake")) {
                    Intent intent = new Intent(Saved.this, RedVelvetCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Cheesecake")) {
                    Intent intent = new Intent(Saved.this, Cheesecake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Carrot Cake")) {
                    Intent intent = new Intent(Saved.this, CarrotCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Sponge Cake")) {
                    Intent intent = new Intent(Saved.this, SpongeCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Hamburger Bun")) {
                    Intent intent = new Intent(Saved.this, HamburgerBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Hot Dog Bun")) {
                    Intent intent = new Intent(Saved.this, HotDogBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Brioche Bun")) {
                    Intent intent = new Intent(Saved.this, BriocheBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Cinnamon Bun")) {
                    Intent intent = new Intent(Saved.this, CinnamonBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Kaiser Roll")) {
                    Intent intent = new Intent(Saved.this, KaiserRoll.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Croissant")) {
                    Intent intent = new Intent(Saved.this, Croissant.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Danish Pastry")) {
                    Intent intent = new Intent(Saved.this, DanishPastry.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Eclair")) {
                    Intent intent = new Intent(Saved.this, Eclair.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Puff Pastry")) {
                    Intent intent = new Intent(Saved.this, PuffPastry.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Turnover")) {
                    Intent intent = new Intent(Saved.this, Turnover.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Glazed Donuts")) {
                    Intent intent = new Intent(Saved.this, GlazedDoughnut.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Chocolate Frosted Doughnut")) {
                    Intent intent = new Intent(Saved.this, ChocolateFrost.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Jelly Doughnut")) {
                    Intent intent = new Intent(Saved.this, JellyDoughnut.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Boston Cream Doughnut")) {
                    Intent intent = new Intent(Saved.this, BostonCream.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Old-Fashioned Doughnut")) {
                    Intent intent = new Intent(Saved.this, OldFashioned.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Chocolate Chip Cookie")) {
                    Intent intent = new Intent(Saved.this, ChocolateChip.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Graham Balls")) {
                    Intent intent = new Intent(Saved.this, GrahamBalls.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Sugar Cookie")) {
                    Intent intent = new Intent(Saved.this, SugarCookie.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Peanut Butter Cookie")) {
                    Intent intent = new Intent(Saved.this, PeanutButter.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Snickerdoodle")) {
                    Intent intent = new Intent(Saved.this, Snickerdoodle.class);
                    startActivity(intent);
                } else {
                }
            }
        });

        ImageView img1 = findViewById(R.id.button1);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs1 = new Intent(Saved.this, Options.class);
                startActivity(hatdogs1);
            }
        });

        ImageView img2 = findViewById(R.id.button2);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs2 = new Intent(Saved.this, MainActivity.class);
                startActivity(hatdogs2);
            }
        });

        ImageView img0 = findViewById(R.id.button3);
        img0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs0 = new Intent(Saved.this, Saved.class);
                startActivity(hatdogs0);
            }
        });

    }
}