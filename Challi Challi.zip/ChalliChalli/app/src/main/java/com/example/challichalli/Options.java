package com.example.challichalli;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Options extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_options);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText searchView = findViewById(R.id.searchView);

        ImageView validateButton = findViewById(R.id.btn14_activity);
        validateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredPassword = searchView.getText().toString();
                if (enteredPassword.equals("Sourdough")) {
                    Intent intent = new Intent(Options.this, Sourdough.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Baguette")) {
                    Intent intent = new Intent(Options.this, Baguette.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Rye Bread")) {
                    Intent intent = new Intent(Options.this, RyeBread.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Whole Wheat Bread")) {
                    Intent intent = new Intent(Options.this, WholeWheatBread.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Ciabatta")) {
                    Intent intent = new Intent(Options.this, Ciabatta.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Chocolate Cake")) {
                    Intent intent = new Intent(Options.this, ChocolatecCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Red Velvet Cake")) {
                    Intent intent = new Intent(Options.this, RedVelvetCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Cheesecake")) {
                    Intent intent = new Intent(Options.this, Cheesecake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Carrot Cake")) {
                    Intent intent = new Intent(Options.this, CarrotCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Sponge Cake")) {
                    Intent intent = new Intent(Options.this, SpongeCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Hamburger Bun")) {
                    Intent intent = new Intent(Options.this, HamburgerBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Hot Dog Bun")) {
                    Intent intent = new Intent(Options.this, HotDogBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Brioche Bun")) {
                    Intent intent = new Intent(Options.this, BriocheBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Cinnamon Bun")) {
                    Intent intent = new Intent(Options.this, CinnamonBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Kaiser Roll")) {
                    Intent intent = new Intent(Options.this, KaiserRoll.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Croissant")) {
                    Intent intent = new Intent(Options.this, Croissant.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Danish Pastry")) {
                    Intent intent = new Intent(Options.this, DanishPastry.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Eclair")) {
                    Intent intent = new Intent(Options.this, Eclair.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Puff Pastry")) {
                    Intent intent = new Intent(Options.this, PuffPastry.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Turnover")) {
                    Intent intent = new Intent(Options.this, Turnover.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Glazed Donuts")) {
                    Intent intent = new Intent(Options.this, GlazedDoughnut.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Chocolate Frosted Doughnut")) {
                    Intent intent = new Intent(Options.this, ChocolateFrost.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Jelly Doughnut")) {
                    Intent intent = new Intent(Options.this, JellyDoughnut.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Boston Cream Doughnut")) {
                    Intent intent = new Intent(Options.this, BostonCream.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Old-Fashioned Doughnut")) {
                    Intent intent = new Intent(Options.this, OldFashioned.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Chocolate Chip Cookie")) {
                    Intent intent = new Intent(Options.this, ChocolateChip.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Graham Balls")) {
                    Intent intent = new Intent(Options.this, GrahamBalls.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Sugar Cookie")) {
                    Intent intent = new Intent(Options.this, SugarCookie.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Peanut Butter Cookie")) {
                    Intent intent = new Intent(Options.this, PeanutButter.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Snickerdoodle")) {
                    Intent intent = new Intent(Options.this, Snickerdoodle.class);
                    startActivity(intent);
                } else {
                }
            }
        });

        ImageView img1 = findViewById(R.id.button1);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs1 = new Intent(Options.this, Options.class);
                startActivity(hatdogs1);
            }
        });

        ImageView img2 = findViewById(R.id.button2);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs2 = new Intent(Options.this, MainActivity.class);
                startActivity(hatdogs2);
            }
        });

        ImageView img3 = (ImageView) findViewById (R.id.imageView13);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs3 = new Intent(Options.this, Transaction.class);
                startActivity(hatdogs3);
            }
        });

        Button btn1 = findViewById(R.id.Button14);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog1 = new Intent(Options.this, Bread.class);
                startActivity(hatdog1);
            }
        });

        ImageView img4 = (ImageView) findViewById (R.id.imageView11);
        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs4 = new Intent(Options.this, Popular.class);
                startActivity(hatdogs4);
            }
        });

        Button btn2 = findViewById(R.id.Button12);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog2 = new Intent(Options.this, Popular.class);
                startActivity(hatdog2);
            }
        });

        ImageView img5 = (ImageView) findViewById (R.id.imageView12);
        img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs5 = new Intent(Options.this, Savers.class);
                startActivity(hatdogs5);
            }
        });

        Button btn3 = findViewById(R.id.Button13);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog3 = new Intent(Options.this, Savers.class);
                startActivity(hatdog3);
            }
        });

        ImageView img6 = (ImageView) findViewById (R.id.imageView14);
        img6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs6 = new Intent(Options.this, Cakes.class);
                startActivity(hatdogs6);
            }
        });

        Button btn4 = findViewById(R.id.Button15);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog4 = new Intent(Options.this, Cakes.class);
                startActivity(hatdog4);
            }
        });

        ImageView img7 = (ImageView) findViewById (R.id.imageView15);
        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs7= new Intent(Options.this, Buns.class);
                startActivity(hatdogs7);
            }
        });

        Button btn5 = findViewById(R.id.Button16);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog5 = new Intent(Options.this, Buns.class);
                startActivity(hatdog5);
            }
        });

        ImageView img8 = (ImageView) findViewById (R.id.imageView16);
        img8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs8= new Intent(Options.this, Pastries.class);
                startActivity(hatdogs8);
            }
        });

        Button btn6 = findViewById(R.id.Button17);
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog6 = new Intent(Options.this, Pastries.class);
                startActivity(hatdog6);
            }
        });

        ImageView img9 = (ImageView) findViewById (R.id.imageView19);
        img9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs9= new Intent(Options.this, Doughnuts.class);
                startActivity(hatdogs9);
            }
        });

        Button btn7 = findViewById(R.id.Button20);
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog7 = new Intent(Options.this, Doughnuts.class);
                startActivity(hatdog7);
            }
        });

        ImageView img10 = (ImageView) findViewById (R.id.imageView18);
        img10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs10= new Intent(Options.this, Cookies.class);
                startActivity(hatdogs10);
            }
        });

        Button btn8 = findViewById(R.id.Button19);
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog8 = new Intent(Options.this, Cookies.class);
                startActivity(hatdog8);
            }
        });


    }
}