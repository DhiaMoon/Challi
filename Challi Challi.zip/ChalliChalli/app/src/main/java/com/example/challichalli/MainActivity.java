package com.example.challichalli;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        EditText searchView = findViewById(R.id.searchView);
        ScrollView scrollView = findViewById(R.id.scrollView);
        LinearLayout ScroollinearLayout = (LinearLayout) scrollView.getChildAt(0);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        searchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                for (int i = 0; i < ScroollinearLayout.getChildCount(); i++) {
                    LinearLayout linearLayout = (LinearLayout) ScroollinearLayout.getChildAt(i);
                    LinearLayout ChildLinearLayout = (LinearLayout) linearLayout.getChildAt(1);
                    Button ChildChildLinearLayout = (Button) ChildLinearLayout.getChildAt(0);

                    if (ChildChildLinearLayout.getText().toString().toLowerCase().contains(s.toString().toLowerCase())) {
                        linearLayout.setVisibility(View.VISIBLE);
                    } else {
                        linearLayout.setVisibility(View.GONE);
                    }
                }
            }
        });

        ImageView img1 = findViewById(R.id.button1);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs1 = new Intent(MainActivity.this, Options.class);
                startActivity(hatdogs1);
            }
        });

        ImageView img2 = findViewById(R.id.button2);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs2 = new Intent(MainActivity.this, MainActivity.class);
                startActivity(hatdogs2);
            }
        });

        ImageView img0 = findViewById(R.id.button1);
        img0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs0 = new Intent(MainActivity.this, Database.class);
                startActivity(hatdogs0);
            }
        });

        ImageView img002 = findViewById(R.id.button2);
        img002.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs02 = new Intent(MainActivity.this, MainActivity.class);
                startActivity(hatdogs02);
            }
        });

        ImageView img3 = findViewById(R.id.imageView2);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs3 = new Intent(MainActivity.this, Bread.class);
                startActivity(hatdogs3);
            }
        });

        Button btn1 = findViewById(R.id.Button3);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog1 = new Intent(MainActivity.this, Bread.class);
                startActivity(hatdog1);
            }
        });

        ImageView img4 = findViewById(R.id.imageView3);
        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs4 = new Intent(MainActivity.this, Cakes.class);
                startActivity(hatdogs4);
            }
        });

        Button btn2 = findViewById(R.id.Button4);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog2 = new Intent(MainActivity.this, Cakes.class);
                startActivity(hatdog2);
            }
        });

        ImageView img5 = findViewById(R.id.imageView4);
        img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs5 = new Intent(MainActivity.this, Buns.class);
                startActivity(hatdogs5);
            }
        });

        Button btn3 = findViewById(R.id.Button5);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog3 = new Intent(MainActivity.this, Buns.class);
                startActivity(hatdog3);
            }
        });

        ImageView img6 = findViewById(R.id.imageView5);
        img6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs6 = new Intent(MainActivity.this, Pastries.class);
                startActivity(hatdogs6);
            }
        });

        Button btn4 = findViewById(R.id.Button6);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog4 = new Intent(MainActivity.this, Pastries.class);
                startActivity(hatdog4);
            }
        });

        ImageView img7 = findViewById(R.id.imageView7);
        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs7 = new Intent(MainActivity.this, Cookies.class);
                startActivity(hatdogs7);
            }
        });

        Button btn5 = findViewById(R.id.Button8);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog5 = new Intent(MainActivity.this, Cookies.class);
                startActivity(hatdog5);
            }
        });

        ImageView img8 = findViewById(R.id.imageView8);
        img8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs8 = new Intent(MainActivity.this, Doughnuts.class);
                startActivity(hatdogs8);
            }
        });

        Button btn6 = findViewById(R.id.Button9);
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog6 = new Intent(MainActivity.this, Doughnuts.class);
                startActivity(hatdog6);
            }
        });

        ImageView img9 = findViewById(R.id.imageView11);
        img9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs9 = new Intent(MainActivity.this, Sourdough.class);
                startActivity(hatdogs9);
            }
        });

        Button btn7 = findViewById(R.id.Button12);
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog7 = new Intent(MainActivity.this, Sourdough.class);
                startActivity(hatdog7);
            }
        });

        ImageView img10 = findViewById(R.id.imageView12);
        img10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs10 = new Intent(MainActivity.this, Croissant.class);
                startActivity(hatdogs10);
            }
        });

        Button btn8 = findViewById(R.id.Button13);
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog8 = new Intent(MainActivity.this, Croissant.class);
                startActivity(hatdog8);
            }
        });

        ImageView img11 = findViewById(R.id.imageView15);
        img11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs11 = new Intent(MainActivity.this, Eclair.class);
                startActivity(hatdogs11);
            }
        });

        Button btn9 = findViewById(R.id.Button16);
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog9 = new Intent(MainActivity.this, Eclair.class);
                startActivity(hatdog9);
            }
        });

        ImageView img12 = findViewById(R.id.imageView13);
        img12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs12 = new Intent(MainActivity.this, Cheesecake.class);
                startActivity(hatdogs12);
            }
        });

        Button btn10 = findViewById(R.id.Button14);
        btn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog10 = new Intent(MainActivity.this, Cheesecake.class);
                startActivity(hatdog10);
            }
        });

        ImageView img13 = findViewById(R.id.imageView14);
        img13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs13 = new Intent(MainActivity.this, GrahamBalls.class);
                startActivity(hatdogs13);
            }
        });

        Button btn11 = findViewById(R.id.Button15);
        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog11 = new Intent(MainActivity.this, GrahamBalls.class);
                startActivity(hatdog11);
            }
        });

        ImageView img14 = findViewById(R.id.imageView16);
        img14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs14 = new Intent(MainActivity.this, BriocheBun.class);
                startActivity(hatdogs14);
            }
        });

        Button btn12 = findViewById(R.id.Button17);
        btn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog12 = new Intent(MainActivity.this, BriocheBun.class);
                startActivity(hatdog12);
            }
        });

        Button btn03 = findViewById(R.id.Sourdough2);
        btn03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog03 = new Intent(MainActivity.this, Sourdough.class);
                startActivity(hatdog03);
            }
        });

        ImageView img03 = findViewById(R.id.Sourdough1);
        img03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs03 = new Intent(MainActivity.this, Sourdough.class);
                startActivity(hatdogs03);
            }
        });

        TextView txt0 = findViewById(R.id.Sourdough3);
        txt0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss0 = new Intent(MainActivity.this, Sourdough.class);
                startActivity(hatdogss0);
            }
        });

        Button btn04 = findViewById(R.id.WholeWheatBread2);
        btn04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog04 = new Intent(MainActivity.this, WholeWheatBread.class);
                startActivity(hatdog04);
            }
        });

        ImageView img04 = findViewById(R.id.WholeWheatBread1);
        img04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs04 = new Intent(MainActivity.this, WholeWheatBread.class);
                startActivity(hatdogs04);
            }
        });

        TextView txt01 = findViewById(R.id.WholeWheatBread3);
        txt01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss01 = new Intent(MainActivity.this, WholeWheatBread.class);
                startActivity(hatdogss01);
            }
        });

        Button btn05 = findViewById(R.id.RyebRead2);
        btn05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog05 = new Intent(MainActivity.this, RyeBread.class);
                startActivity(hatdog05);
            }
        });

        ImageView img05 = findViewById(R.id.RyebRead1);
        img05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs05 = new Intent(MainActivity.this, RyeBread.class);
                startActivity(hatdogs05);
            }
        });

        TextView txt02 = findViewById(R.id.RyebRead3);
        txt02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss02 = new Intent(MainActivity.this, RyeBread.class);
                startActivity(hatdogss02);
            }
        });

        Button btn06 = findViewById(R.id.Baguette2);
        btn06.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog06 = new Intent(MainActivity.this, Baguette.class);
                startActivity(hatdog06);
            }
        });

        ImageView img06 = findViewById(R.id.Baguette1);
        img06.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs06 = new Intent(MainActivity.this, Baguette.class);
                startActivity(hatdogs06);
            }
        });

        TextView txt03 = findViewById(R.id.Baguette3);
        txt03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss03 = new Intent(MainActivity.this, Baguette.class);
                startActivity(hatdogss03);
            }
        });

        Button btn07 = findViewById(R.id.Ciabatta2);
        btn07.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog07 = new Intent(MainActivity.this, Ciabatta.class);
                startActivity(hatdog07);
            }
        });

        ImageView img07 = findViewById(R.id.Ciabatta1);
        img07.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs07 = new Intent(MainActivity.this, Ciabatta.class);
                startActivity(hatdogs07);
            }
        });

        TextView txt04 = findViewById(R.id.Ciabatta3);
        txt04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss04 = new Intent(MainActivity.this, Ciabatta.class);
                startActivity(hatdogss04);
            }
        });

        Button btn31 = findViewById(R.id.ChocolateCake2);
        btn31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog31 = new Intent(MainActivity.this, ChocolatecCake.class);
                startActivity(hatdog31);
            }
        });

        ImageView img31 = findViewById(R.id.ChocolateCake1);
        img31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs31 = new Intent(MainActivity.this, ChocolatecCake.class);
                startActivity(hatdogs31);
            }
        });

        TextView txt11 = findViewById(R.id.ChocolateCake3);
        txt11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss11 = new Intent(MainActivity.this, ChocolatecCake.class);
                startActivity(hatdogss11);
            }
        });

        Button btn41 = findViewById(R.id.RedVelvetCake2);
        btn41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog41 = new Intent(MainActivity.this, RedVelvetCake.class);
                startActivity(hatdog41);
            }
        });

        ImageView img41 = findViewById(R.id.RedVelvetCake1);
        img41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs41 = new Intent(MainActivity.this, RedVelvetCake.class);
                startActivity(hatdogs41);
            }
        });

        TextView txt111 = findViewById(R.id.RedVelvetCake3);
        txt111.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss111 = new Intent(MainActivity.this, RedVelvetCake.class);
                startActivity(hatdogss111);
            }
        });

        Button btn51 = findViewById(R.id.Cheesecake2);
        btn51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog51 = new Intent(MainActivity.this, Cheesecake.class);
                startActivity(hatdog51);
            }
        });

        ImageView img51 = findViewById(R.id.Cheesecake1);
        img51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs51 = new Intent(MainActivity.this, Cheesecake.class);
                startActivity(hatdogs51);
            }
        });

        TextView txt21 = findViewById(R.id.Cheesecake3);
        txt21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss21 = new Intent(MainActivity.this, Cheesecake.class);
                startActivity(hatdogss21);
            }
        });

        Button btn61 = findViewById(R.id.CarrotCake2);
        btn61.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog61 = new Intent(MainActivity.this, CarrotCake.class);
                startActivity(hatdog61);
            }
        });

        ImageView img61 = findViewById(R.id.CarrotCake1);
        img61.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs61 = new Intent(MainActivity.this, CarrotCake.class);
                startActivity(hatdogs61);
            }
        });

        TextView txt31 = findViewById(R.id.CarrotCake3);
        txt31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss31 = new Intent(MainActivity.this, CarrotCake.class);
                startActivity(hatdogss31);
            }
        });

        Button btn71 = findViewById(R.id.SpongeCake2);
        btn71.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog71 = new Intent(MainActivity.this, SpongeCake.class);
                startActivity(hatdog71);
            }
        });

        ImageView img71 = findViewById(R.id.SpongeCake1);
        img71.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs71 = new Intent(MainActivity.this, SpongeCake.class);
                startActivity(hatdogs71);
            }
        });

        TextView txt41 = findViewById(R.id.SpongeCake3);
        txt41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss41 = new Intent(MainActivity.this, SpongeCake.class);
                startActivity(hatdogss41);
            }
        });

        Button btn32 = findViewById(R.id.HamburgerBun2);
        btn32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog32 = new Intent(MainActivity.this, HamburgerBun.class);
                startActivity(hatdog32);
            }
        });

        ImageView img32 = findViewById(R.id.HamburgerBun1);
        img32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs32 = new Intent(MainActivity.this, HamburgerBun.class);
                startActivity(hatdogs32);
            }
        });

        TextView txt20 = findViewById(R.id.HamburgerBun3);
        txt20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss20 = new Intent(MainActivity.this, HamburgerBun.class);
                startActivity(hatdogss20);
            }
        });

        Button btn42 = findViewById(R.id.HotDogBun2);
        btn42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog42 = new Intent(MainActivity.this, HotDogBun.class);
                startActivity(hatdog42);
            }
        });

        ImageView img42 = findViewById(R.id.HotDogBun1);
        img42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs42 = new Intent(MainActivity.this, HotDogBun.class);
                startActivity(hatdogs42);
            }
        });

        TextView txt12 = findViewById(R.id.HotDogBun3);
        txt12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss12 = new Intent(MainActivity.this, HotDogBun.class);
                startActivity(hatdogss12);
            }
        });

        Button btn52 = findViewById(R.id.BriocheBun2);
        btn52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog52 = new Intent(MainActivity.this, BriocheBun.class);
                startActivity(hatdog52);
            }
        });

        ImageView img52 = findViewById(R.id.BriocheBun1);
        img52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs52 = new Intent(MainActivity.this, BriocheBun.class);
                startActivity(hatdogs52);
            }
        });

        TextView txt22 = findViewById(R.id.BriocheBun3);
        txt22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss22 = new Intent(MainActivity.this, BriocheBun.class);
                startActivity(hatdogss22);
            }
        });

        Button btn62 = findViewById(R.id.CinnamonBun2);
        btn62.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog62 = new Intent(MainActivity.this, CinnamonBun.class);
                startActivity(hatdog62);
            }
        });

        ImageView img62 = findViewById(R.id.CinnamonBun1);
        img62.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs62 = new Intent(MainActivity.this, CinnamonBun.class);
                startActivity(hatdogs62);
            }
        });

        TextView txt32 = findViewById(R.id.CinnamonBun3);
        txt32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss32 = new Intent(MainActivity.this, CinnamonBun.class);
                startActivity(hatdogss32);
            }
        });

        Button btn72 = findViewById(R.id.KaiserRoll2);
        btn72.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog72 = new Intent(MainActivity.this, KaiserRoll.class);
                startActivity(hatdog72);
            }
        });

        ImageView img72 = findViewById(R.id.KaiserRoll1);
        img72.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs72 = new Intent(MainActivity.this, KaiserRoll.class);
                startActivity(hatdogs72);
            }
        });

        TextView txt42 = findViewById(R.id.KaiserRoll3);
        txt42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss42 = new Intent(MainActivity.this, KaiserRoll.class);
                startActivity(hatdogss42);
            }
        });

        Button btn34 = findViewById(R.id.GlazedDoughnut2);
        btn34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog34 = new Intent(MainActivity.this, GlazedDoughnut.class);
                startActivity(hatdog34);
            }
        });

        ImageView img34 = findViewById(R.id.GlazedDoughnut1);
        img34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs34 = new Intent(MainActivity.this, GlazedDoughnut.class);
                startActivity(hatdogs34);
            }
        });

        TextView txt40 = findViewById(R.id.GlazedDoughnut3);
        txt40.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss40 = new Intent(MainActivity.this, GlazedDoughnut.class);
                startActivity(hatdogss40);
            }
        });

        Button btn44 = findViewById(R.id.ChocolateFrost2);
        btn44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog44 = new Intent(MainActivity.this, ChocolateFrost.class);
                startActivity(hatdog44);
            }
        });

        ImageView img44 = findViewById(R.id.ChocolateFrost1);
        img44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs44 = new Intent(MainActivity.this, ChocolateFrost.class);
                startActivity(hatdogs44);
            }
        });

        TextView txt14 = findViewById(R.id.ChocolateFrost3);
        txt14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss14 = new Intent(MainActivity.this, ChocolateFrost.class);
                startActivity(hatdogss14);
            }
        });

        Button btn54 = findViewById(R.id.JellyDoughnut2);
        btn54.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog54 = new Intent(MainActivity.this, JellyDoughnut.class);
                startActivity(hatdog54);
            }
        });

        ImageView img54 = findViewById(R.id.JellyDoughnut1);
        img54.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs54 = new Intent(MainActivity.this, JellyDoughnut.class);
                startActivity(hatdogs54);
            }
        });

        TextView txt24 = findViewById(R.id.JellyDoughnut3);
        txt24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss24 = new Intent(MainActivity.this, JellyDoughnut.class);
                startActivity(hatdogss24);
            }
        });

        Button btn64 = findViewById(R.id.BostonCream2);
        btn64.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog64 = new Intent(MainActivity.this, BostonCream.class);
                startActivity(hatdog64);
            }
        });

        ImageView img64 = findViewById(R.id.BostonCream1);
        img64.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs64 = new Intent(MainActivity.this, BostonCream.class);
                startActivity(hatdogs64);
            }
        });

        TextView txt34 = findViewById(R.id.BostonCream3);
        txt34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss34 = new Intent(MainActivity.this, BostonCream.class);
                startActivity(hatdogss34);
            }
        });

        Button btn74 = findViewById(R.id.OldFashioned2);
        btn74.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog74 = new Intent(MainActivity.this, OldFashioned.class);
                startActivity(hatdog74);
            }
        });

        ImageView img74 = findViewById(R.id.OldFashioned1);
        img74.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs74 = new Intent(MainActivity.this, OldFashioned.class);
                startActivity(hatdogs74);
            }
        });

        TextView txt44 = findViewById(R.id.OldFashioned3);
        txt44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss44 = new Intent(MainActivity.this, OldFashioned.class);
                startActivity(hatdogss44);
            }
        });

        Button btn33 = findViewById(R.id.Croissant2);
        btn33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog33 = new Intent(MainActivity.this, Croissant.class);
                startActivity(hatdog33);
            }
        });

        ImageView img33 = findViewById(R.id.Croissant1);
        img33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs33 = new Intent(MainActivity.this, Croissant.class);
                startActivity(hatdogs33);
            }
        });

        TextView txt30 = findViewById(R.id.Croissant3);
        txt30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss30 = new Intent(MainActivity.this, Croissant.class);
                startActivity(hatdogss30);
            }
        });

        Button btn43 = findViewById(R.id.DanishPastry2);
        btn43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog43 = new Intent(MainActivity.this, DanishPastry.class);
                startActivity(hatdog43);
            }
        });

        ImageView img43 = findViewById(R.id.DanishPastry1);
        img43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs43 = new Intent(MainActivity.this, DanishPastry.class);
                startActivity(hatdogs43);
            }
        });

        TextView txt13 = findViewById(R.id.DanishPastry3);
        txt13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss13 = new Intent(MainActivity.this, DanishPastry.class);
                startActivity(hatdogss13);
            }
        });

        Button btn53 = findViewById(R.id.Eclair2);
        btn53.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog53 = new Intent(MainActivity.this, Eclair.class);
                startActivity(hatdog53);
            }
        });

        ImageView img53 = findViewById(R.id.Eclair1);
        img53.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs53 = new Intent(MainActivity.this, Eclair.class);
                startActivity(hatdogs53);
            }
        });

        TextView txt23 = findViewById(R.id.Eclair3);
        txt23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss23 = new Intent(MainActivity.this, Eclair.class);
                startActivity(hatdogss23);
            }
        });

        Button btn63 = findViewById(R.id.PuffPastry2);
        btn63.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog63 = new Intent(MainActivity.this, PuffPastry.class);
                startActivity(hatdog63);
            }
        });

        ImageView img63 = findViewById(R.id.PuffPastry1);
        img63.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs63 = new Intent(MainActivity.this, PuffPastry.class);
                startActivity(hatdogs63);
            }
        });

        TextView txt33 = findViewById(R.id.PuffPastry3);
        txt33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss33 = new Intent(MainActivity.this, PuffPastry.class);
                startActivity(hatdogss33);
            }
        });

        Button btn73 = findViewById(R.id.Turnover2);
        btn73.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog73 = new Intent(MainActivity.this, Turnover.class);
                startActivity(hatdog73);
            }
        });

        ImageView img73 = findViewById(R.id.Turnover1);
        img73.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs73 = new Intent(MainActivity.this, Turnover.class);
                startActivity(hatdogs73);
            }
        });

        TextView txt43 = findViewById(R.id.Turnover3);
        txt43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss43 = new Intent(MainActivity.this, Turnover.class);
                startActivity(hatdogss43);
            }
        });

        Button btn35 = findViewById(R.id.ChocolateChip2);
        btn35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog35 = new Intent(MainActivity.this, ChocolateChip.class);
                startActivity(hatdog35);
            }
        });

        ImageView img35 = findViewById(R.id.ChocolateChip1);
        img35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs35 = new Intent(MainActivity.this, ChocolateChip.class);
                startActivity(hatdogs35);
            }
        });

        TextView txt50 = findViewById(R.id.ChocolateChip3);
        txt50.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss50 = new Intent(MainActivity.this, ChocolateChip.class);
                startActivity(hatdogss50);
            }
        });

        Button btn45 = findViewById(R.id.GrahamBalls2);
        btn45.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog45 = new Intent(MainActivity.this, GrahamBalls.class);
                startActivity(hatdog45);
            }
        });

        ImageView img45 = findViewById(R.id.GrahamBalls1);
        img45.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs45 = new Intent(MainActivity.this, GrahamBalls.class);
                startActivity(hatdogs45);
            }
        });

        TextView txt15 = findViewById(R.id.GrahamBalls3);
        txt15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss15 = new Intent(MainActivity.this, GrahamBalls.class);
                startActivity(hatdogss15);
            }
        });

        Button btn55 = findViewById(R.id.SugarCookie2);
        btn55.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog55 = new Intent(MainActivity.this, SugarCookie.class);
                startActivity(hatdog55);
            }
        });

        ImageView img55 = findViewById(R.id.SugarCookie1);
        img55.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs55 = new Intent(MainActivity.this, SugarCookie.class);
                startActivity(hatdogs55);
            }
        });

        TextView txt25 = findViewById(R.id.SugarCookie3);
        txt25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss25 = new Intent(MainActivity.this, SugarCookie.class);
                startActivity(hatdogss25);
            }
        });

        Button btn65 = findViewById(R.id.PeanutButter2);
        btn65.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog65 = new Intent(MainActivity.this, PeanutButter.class);
                startActivity(hatdog65);
            }
        });

        ImageView img65 = findViewById(R.id.PeanutButter1);
        img65.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs65 = new Intent(MainActivity.this, PeanutButter.class);
                startActivity(hatdogs65);
            }
        });

        TextView txt35 = findViewById(R.id.PeanutButter3);
        txt35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogss35 = new Intent(MainActivity.this, PeanutButter.class);
                startActivity(hatdogss35);
            }
        });

        Button btn75 = findViewById(R.id.Snickerdoodle2);
        btn75.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog75 = new Intent(MainActivity.this, Snickerdoodle.class);
                startActivity(hatdog75);
            }
        });

        ImageView img75 = findViewById(R.id.Snickerdoodle1);
        img75.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs75 = new Intent(MainActivity.this, Snickerdoodle.class);
                startActivity(hatdogs75);
            }
        });

    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }


}