package com.example.challichalli;

import android.widget.Filter;
import android.widget.Filter.FilterListener;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class MainActivity extends AppCompatActivity {

    private EditText searchEditText;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> itemList;
    private Map<String, Class<?>> itemToActivityMap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText searchView = findViewById(R.id.searchView);

        ImageView validateButton = findViewById(R.id.btn14_activity);
        validateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredPassword = searchView.getText().toString();
                if (enteredPassword.equals("Sourdough")) {
                    Intent intent = new Intent(MainActivity.this, Sourdough.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Baguette")) {
                    Intent intent = new Intent(MainActivity.this, Baguette.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Rye Bread")) {
                    Intent intent = new Intent(MainActivity.this, RyeBread.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Whole Wheat Bread")) {
                    Intent intent = new Intent(MainActivity.this, WholeWheatBread.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Ciabatta")) {
                    Intent intent = new Intent(MainActivity.this, Ciabatta.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Chocolate Cake")) {
                    Intent intent = new Intent(MainActivity.this, ChocolatecCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Red Velvet Cake")) {
                    Intent intent = new Intent(MainActivity.this, RedVelvetCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Cheesecake")) {
                    Intent intent = new Intent(MainActivity.this, Cheesecake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Carrot Cake")) {
                    Intent intent = new Intent(MainActivity.this, CarrotCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Sponge Cake")) {
                    Intent intent = new Intent(MainActivity.this, SpongeCake.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Hamburger Bun")) {
                    Intent intent = new Intent(MainActivity.this, HamburgerBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Hot Dog Bun")) {
                    Intent intent = new Intent(MainActivity.this, HotDogBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Brioche Bun")) {
                    Intent intent = new Intent(MainActivity.this, BriocheBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Cinnamon Bun")) {
                    Intent intent = new Intent(MainActivity.this, CinnamonBun.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Kaiser Roll")) {
                    Intent intent = new Intent(MainActivity.this, KaiserRoll.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Croissant")) {
                    Intent intent = new Intent(MainActivity.this, Croissant.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Danish Pastry")) {
                    Intent intent = new Intent(MainActivity.this, DanishPastry.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Eclair")) {
                    Intent intent = new Intent(MainActivity.this, Eclair.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Puff Pastry")) {
                    Intent intent = new Intent(MainActivity.this, PuffPastry.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Turnover")) {
                    Intent intent = new Intent(MainActivity.this, Turnover.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Glazed Donuts")) {
                    Intent intent = new Intent(MainActivity.this, GlazedDoughnut.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Chocolate Frosted Doughnut")) {
                    Intent intent = new Intent(MainActivity.this, ChocolateFrost.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Jelly Doughnut")) {
                    Intent intent = new Intent(MainActivity.this, JellyDoughnut.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Boston Cream Doughnut")) {
                    Intent intent = new Intent(MainActivity.this, BostonCream.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Old-Fashioned Doughnut")) {
                    Intent intent = new Intent(MainActivity.this, OldFashioned.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Chocolate Chip Cookie")) {
                    Intent intent = new Intent(MainActivity.this, ChocolateChip.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Graham Balls")) {
                    Intent intent = new Intent(MainActivity.this, GrahamBalls.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Sugar Cookie")) {
                    Intent intent = new Intent(MainActivity.this, SugarCookie.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Peanut Butter Cookie")) {
                    Intent intent = new Intent(MainActivity.this, PeanutButter.class);
                    startActivity(intent);
                }
                if (enteredPassword.equals("Snickerdoodle")) {
                    Intent intent = new Intent(MainActivity.this, Snickerdoodle.class);
                    startActivity(intent);
                } else {
                }
            }
        });

        ImageView img1 = findViewById(R.id.button1);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs1 = new Intent(MainActivity.this, Options.class);
                startActivity(hatdogs1);
            }
        });

        ImageView img2 = findViewById(R.id.button2);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs2 = new Intent(MainActivity.this, MainActivity.class);
                startActivity(hatdogs2);
            }
        });

        ImageView img0 = findViewById(R.id.button3);
        img0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs0 = new Intent(MainActivity.this, Transaction.class);
                startActivity(hatdogs0);
            }
        });

        ImageView img002 = findViewById(R.id.button2);
        img002.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs02 = new Intent(MainActivity.this, MainActivity.class);
                startActivity(hatdogs02);
            }
        });

        ImageView img3 = findViewById(R.id.imageView2);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs3 = new Intent(MainActivity.this, Bread.class);
                startActivity(hatdogs3);
            }
        });

        Button btn1 = findViewById(R.id.Button3);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog1 = new Intent(MainActivity.this, Bread.class);
                startActivity(hatdog1);
            }
        });

        ImageView img4 = findViewById(R.id.imageView3);
        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs4 = new Intent(MainActivity.this, Cakes.class);
                startActivity(hatdogs4);
            }
        });

        Button btn2 = findViewById(R.id.Button4);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog2 = new Intent(MainActivity.this, Cakes.class);
                startActivity(hatdog2);
            }
        });

        ImageView img5 = findViewById(R.id.imageView4);
        img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs5 = new Intent(MainActivity.this, Buns.class);
                startActivity(hatdogs5);
            }
        });

        Button btn3 = findViewById(R.id.Button5);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog3 = new Intent(MainActivity.this, Buns.class);
                startActivity(hatdog3);
            }
        });

        ImageView img6 = findViewById(R.id.imageView5);
        img6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs6 = new Intent(MainActivity.this, Pastries.class);
                startActivity(hatdogs6);
            }
        });

        Button btn4 = findViewById(R.id.Button6);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog4 = new Intent(MainActivity.this, Pastries.class);
                startActivity(hatdog4);
            }
        });

        ImageView img7 = findViewById(R.id.imageView7);
        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs7 = new Intent(MainActivity.this, Cookies.class);
                startActivity(hatdogs7);
            }
        });

        Button btn5 = findViewById(R.id.Button8);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog5 = new Intent(MainActivity.this, Cookies.class);
                startActivity(hatdog5);
            }
        });

        ImageView img8 = findViewById(R.id.imageView8);
        img8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs8 = new Intent(MainActivity.this, Doughnuts.class);
                startActivity(hatdogs8);
            }
        });

        Button btn6 = findViewById(R.id.Button9);
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog6 = new Intent(MainActivity.this, Doughnuts.class);
                startActivity(hatdog6);
            }
        });

        ImageView img9 = findViewById(R.id.imageView11);
        img9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs9 = new Intent(MainActivity.this, Sourdough.class);
                startActivity(hatdogs9);
            }
        });

        Button btn7 = findViewById(R.id.Button12);
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog7 = new Intent(MainActivity.this, Sourdough.class);
                startActivity(hatdog7);
            }
        });

        ImageView img10 = findViewById(R.id.imageView12);
        img10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs10 = new Intent(MainActivity.this, Croissant.class);
                startActivity(hatdogs10);
            }
        });

        Button btn8 = findViewById(R.id.Button13);
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog8 = new Intent(MainActivity.this, Croissant.class);
                startActivity(hatdog8);
            }
        });

        ImageView img11 = findViewById(R.id.imageView15);
        img11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs11 = new Intent(MainActivity.this, Eclair.class);
                startActivity(hatdogs11);
            }
        });

        Button btn9 = findViewById(R.id.Button16);
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog9 = new Intent(MainActivity.this, Eclair.class);
                startActivity(hatdog9);
            }
        });

        ImageView img12 = findViewById(R.id.imageView13);
        img12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs12 = new Intent(MainActivity.this, Cheesecake.class);
                startActivity(hatdogs12);
            }
        });

        Button btn10 = findViewById(R.id.Button14);
        btn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog10 = new Intent(MainActivity.this, Cheesecake.class);
                startActivity(hatdog10);
            }
        });

        ImageView img13 = findViewById(R.id.imageView14);
        img13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs13 = new Intent(MainActivity.this, GrahamBalls.class);
                startActivity(hatdogs13);
            }
        });

        Button btn11 = findViewById(R.id.Button15);
        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog11 = new Intent(MainActivity.this, GrahamBalls.class);
                startActivity(hatdog11);
            }
        });

        ImageView img14 = findViewById(R.id.imageView16);
        img14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdogs14 = new Intent(MainActivity.this, BriocheBun.class);
                startActivity(hatdogs14);
            }
        });

        Button btn12 = findViewById(R.id.Button17);
        btn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent hatdog12 = new Intent(MainActivity.this, BriocheBun.class);
                startActivity(hatdog12);
            }
        });

    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

}